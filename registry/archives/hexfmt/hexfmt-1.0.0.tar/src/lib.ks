// hexfmt: padding and hexadecimal text. Pure computation.

fn digits() -> List<String> {
    return ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"]
}

// Prepends fill until the text is at least width characters long.
fn pad_left(text: String, width: Int, fill: String) -> String or Error {
    if fill.length() != 1 {
        return Error("hexfmt.pad_left: fill must be one character")
    }
    let mut out = text
    while out.length() < width {
        out = "{fill}{out}"
    }
    return out
}

// Appends fill until the text is at least width characters long.
fn pad_right(text: String, width: Int, fill: String) -> String or Error {
    if fill.length() != 1 {
        return Error("hexfmt.pad_right: fill must be one character")
    }
    let mut out = text
    while out.length() < width {
        out = "{out}{fill}"
    }
    return out
}

// Lowercase hexadecimal of a non-negative Int, without a prefix.
fn to_hex(value: Int) -> String or Error {
    if value < 0 {
        return Error("hexfmt.to_hex: value must not be negative")
    }
    if value == 0 {
        return "0"
    }
    let table = digits()
    let mut rest = value
    let mut out = ""
    while rest > 0 {
        let digit = table.get(rest % 16) or return Error("hexfmt.to_hex: internal digit lookup")
        out = "{digit}{out}"
        rest = rest / 16
    }
    return out
}

fn digit_value(code: Int) -> Int {
    if code >= 48 && code <= 57 {
        return code - 48
    }
    if code >= 97 && code <= 102 {
        return code - 87
    }
    if code >= 65 && code <= 70 {
        return code - 55
    }
    return -1
}

// Parses hexadecimal text (upper or lower case, optional "0x" prefix).
fn parse_hex(text: String) -> Int or Error {
    let raw = text.to_bytes()
    let mut index = 0
    if raw.length() >= 2 {
        let first = raw.get(0) or return Error("hexfmt.parse_hex: internal")
        let second = raw.get(1) or return Error("hexfmt.parse_hex: internal")
        if first == 48 && (second == 120 || second == 88) {
            index = 2
        }
    }
    if index >= raw.length() {
        return Error("hexfmt.parse_hex: no digits")
    }
    let mut value = 0
    while index < raw.length() {
        let code = raw.get(index) or return Error("hexfmt.parse_hex: internal")
        let digit = digit_value(code)
        if digit < 0 {
            return Error("hexfmt.parse_hex: not a hexadecimal digit")
        }
        value = value * 16 + digit or return Error("hexfmt.parse_hex: value is outside Int")
        index = index + 1
    }
    return value
}
