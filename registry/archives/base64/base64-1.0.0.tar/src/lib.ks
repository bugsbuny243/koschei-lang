// base64: standard Base64 (RFC 4648, with "=" padding). Pure computation.

fn alphabet() -> List<String> {
    return [
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
        "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
        "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "/"
    ]
}

fn hex_digits() -> List<String> {
    return ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"]
}

fn symbol(table: List<String>, index: Int) -> String or Error {
    let found = table.get(index) or return Error("base64: internal alphabet lookup")
    return found
}

// Encodes bytes as Base64 text.
fn encode_bytes(data: Bytes) -> String or Error {
    let table = alphabet()
    let mut out = ""
    let mut index = 0
    let total = data.length()
    while index < total {
        let b0 = data.get(index) or return Error("base64: internal read")
        let mut b1 = 0
        let mut b2 = 0
        let remaining = total - index
        if remaining > 1 {
            b1 = data.get(index + 1) or return Error("base64: internal read")
        }
        if remaining > 2 {
            b2 = data.get(index + 2) or return Error("base64: internal read")
        }
        let triple = b0 * 65536 + b1 * 256 + b2
        let c0 = symbol(table, triple / 262144) or return Error("base64: internal")
        let c1 = symbol(table, (triple / 4096) % 64) or return Error("base64: internal")
        let mut c2 = "="
        let mut c3 = "="
        if remaining > 1 {
            c2 = symbol(table, (triple / 64) % 64) or return Error("base64: internal")
        }
        if remaining > 2 {
            c3 = symbol(table, triple % 64) or return Error("base64: internal")
        }
        out = "{out}{c0}{c1}{c2}{c3}"
        index = index + 3
    }
    return out
}

// Encodes the UTF-8 bytes of text as Base64.
fn encode(text: String) -> String or Error {
    return encode_bytes(text.to_bytes())
}

fn value_of(code: Int) -> Int {
    if code >= 65 && code <= 90 {
        return code - 65
    }
    if code >= 97 && code <= 122 {
        return code - 71
    }
    if code >= 48 && code <= 57 {
        return code + 4
    }
    if code == 43 {
        return 62
    }
    if code == 47 {
        return 63
    }
    return -1
}

fn byte_hex(table: List<String>, value: Int) -> String or Error {
    let high = table.get(value / 16) or return Error("base64: internal")
    let low = table.get(value % 16) or return Error("base64: internal")
    return "{high}{low}"
}

// Decodes Base64 text to bytes. The length must be a multiple of 4 and
// padding may appear only at the end.
fn decode(text: String) -> Bytes or Error {
    let raw = text.to_bytes()
    let total = raw.length()
    if total % 4 != 0 {
        return Error("base64.decode: length is not a multiple of 4")
    }
    let hex = hex_digits()
    let mut out = ""
    let mut index = 0
    while index < total {
        let mut values = [0, 0, 0, 0]
        let mut padding = 0
        let mut slot = 0
        while slot < 4 {
            let code = raw.get(index + slot) or return Error("base64.decode: internal read")
            if code == 61 {
                if index + 4 != total || slot < 2 {
                    return Error("base64.decode: misplaced padding")
                }
                padding = padding + 1
                values = values.push(0)
            } else {
                if padding > 0 {
                    return Error("base64.decode: data after padding")
                }
                let value = value_of(code)
                if value < 0 {
                    return Error("base64.decode: not a Base64 character")
                }
                values = values.push(value)
            }
            slot = slot + 1
        }
        let v0 = values.get(4) or return Error("base64.decode: internal")
        let v1 = values.get(5) or return Error("base64.decode: internal")
        let v2 = values.get(6) or return Error("base64.decode: internal")
        let v3 = values.get(7) or return Error("base64.decode: internal")
        let triple = v0 * 262144 + v1 * 4096 + v2 * 64 + v3
        let first = byte_hex(hex, triple / 65536) or return Error("base64.decode: internal")
        out = "{out}{first}"
        if padding < 2 {
            let second = byte_hex(hex, (triple / 256) % 256) or return Error("base64.decode: internal")
            out = "{out}{second}"
        }
        if padding < 1 {
            let third = byte_hex(hex, triple % 256) or return Error("base64.decode: internal")
            out = "{out}{third}"
        }
        index = index + 4
    }
    let decoded = bytes_from_hex(out) or return Error("base64.decode: internal hex")
    return decoded
}

// Decodes Base64 text whose bytes are UTF-8 text.
fn decode_text(text: String) -> String or Error {
    let data = decode(text) or return Error("base64.decode_text: not valid Base64")
    let decoded = data.to_text() or return Error("base64.decode_text: the bytes are not UTF-8 text")
    return decoded
}
