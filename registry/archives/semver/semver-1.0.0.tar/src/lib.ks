// semver: MAJOR.MINOR.PATCH versions. Pure computation.
// Pre-release and build suffixes are refused rather than half-supported.

struct Version {
    major: Int,
    minor: Int,
    patch: Int,
}

fn part(text: String) -> Int or Error {
    if text.length() == 0 {
        return Error("semver: empty number")
    }
    let raw = text.to_bytes()
    let mut index = 0
    while index < raw.length() {
        let code = raw.get(index) or return Error("semver: internal")
        if code < 48 || code > 57 {
            return Error("semver: only digits are allowed")
        }
        if index == 0 && code == 48 && raw.length() > 1 {
            return Error("semver: leading zero")
        }
        index = index + 1
    }
    let value = text.to_int() or return Error("semver: number is outside Int")
    return value
}

// Parses "1.2.3". Leading zeros, signs, and extra parts are refused.
fn parse(text: String) -> Version or Error {
    let pieces = text.split(".") or return Error("semver.parse: too many parts")
    if pieces.length() != 3 {
        return Error("semver.parse: expected MAJOR.MINOR.PATCH")
    }
    let a = pieces.get(0) or return Error("semver.parse: internal")
    let b = pieces.get(1) or return Error("semver.parse: internal")
    let c = pieces.get(2) or return Error("semver.parse: internal")
    let major = part(a) or return Error("semver.parse: bad major version")
    let minor = part(b) or return Error("semver.parse: bad minor version")
    let patch = part(c) or return Error("semver.parse: bad patch version")
    return Version { major: major, minor: minor, patch: patch }
}

fn to_text(version: Version) -> String {
    return "{version.major}.{version.minor}.{version.patch}"
}

fn order(a: Int, b: Int) -> Int {
    if a < b {
        return -1
    }
    if a > b {
        return 1
    }
    return 0
}

// -1 when a is older than b, 0 when equal, 1 when newer.
fn compare(a: Version, b: Version) -> Int {
    let major = order(a.major, b.major)
    if major != 0 {
        return major
    }
    let minor = order(a.minor, b.minor)
    if minor != 0 {
        return minor
    }
    return order(a.patch, b.patch)
}

// True when candidate can replace current under semver rules: same major
// version (same minor below 1.0.0) and not older.
fn is_compatible(current: Version, candidate: Version) -> Bool {
    if compare(candidate, current) < 0 {
        return false
    }
    if current.major == 0 {
        return candidate.major == 0 && candidate.minor == current.minor
    }
    return candidate.major == current.major
}

// 0.0.0, a convenient fallback: lib.parse(text) or semver.zero()
fn zero() -> Version {
    return Version { major: 0, minor: 0, patch: 0 }
}

fn is_valid(text: String) -> Bool {
    // parse never yields a negative part, so -1 marks a refusal.
    let parsed = parse(text) or Version { major: -1, minor: 0, patch: 0 }
    return parsed.major >= 0
}
